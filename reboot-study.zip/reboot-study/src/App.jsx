import { useState, useMemo, useEffect } from 'react'
import './App.css'
import provesData from './data/proves.json'

// Claus per a localStorage
const STORAGE_KEY_DISPOSITIUS = 'reboot_client_dispositius'
const STORAGE_KEY_SEQ_ID = 'reboot_client_seq_id'

// Dades d'exemple inicials en català
const DISPOSITIUS_INICIALS = [
  { id: 'RB-A', tipus: 'Portàtil', estat: 'En prova' },
  { id: 'RB-B', tipus: 'Portàtil', estat: 'Apte' },
  { id: 'RB-C', tipus: 'Portàtil', estat: 'Diagnosi' },
]

// Estats possibles de dispositiu
const ESTATS_DISPOSITIU = ['En prova', 'Apte', 'Diagnosi']

// Tipus de dispositius del client
const TIPUS_DISPOSITIU_CLIENT = [
  'Portàtil',
  'Ordinador de sobretaula',
  'Servidor',
  'Pantalla',
  'Tauleta',
  'Telèfon mòbil',
]

function App() {
  // Inicialització des de localStorage amb fallback a les dades inicials
  const [dispositius, setDispositius] = useState(() => {
    try {
      const dadesGuardades = localStorage.getItem(STORAGE_KEY_DISPOSITIUS)
      if (dadesGuardades) {
        const parsed = JSON.parse(dadesGuardades)
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed
        }
      }
    } catch (e) {
      console.error("Error en carregar dispositius de localStorage:", e)
    }
    return DISPOSITIUS_INICIALS
  })

  // Seqüència numèrica per a IDs automàtics (RB-001, RB-002...) guardada a localStorage
  const [seguentIdNum, setSeguentIdNum] = useState(() => {
    try {
      const seqGuardada = localStorage.getItem(STORAGE_KEY_SEQ_ID)
      if (seqGuardada) {
        const num = parseInt(seqGuardada, 10)
        if (!isNaN(num) && num > 0) return num
      }
    } catch (e) {
      console.error("Error en carregar seqüència de localStorage:", e)
    }
    return 1
  })

  const [filtreEstat, setFiltreEstat] = useState('tots')
  const [cerca, setCerca] = useState('')

  // Estat per a la vista de la «Fitxa de vida»
  const [dispositiuActiu, setDispositiuActiu] = useState(null)

  // Estat del formulari de registre
  const [tipusSeleccionat, setTipusSeleccionat] = useState('')
  const [errorTipus, setErrorTipus] = useState('')

  // Identificador generat automàticament (RB-001, RB-002, ...)
  const idGenerat = `RB-${String(seguentIdNum).padStart(3, '0')}`

  // Tancar la fitxa de vida amb la tecla Escape
  useEffect(() => {
    const gestionarTecla = (e) => {
      if (e.key === 'Escape') {
        setDispositiuActiu(null)
      }
    }
    if (dispositiuActiu) {
      window.addEventListener('keydown', gestionarTecla)
    }
    return () => window.removeEventListener('keydown', gestionarTecla)
  }, [dispositiuActiu])

  // Desa automàticament la llista a localStorage quan canvia
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DISPOSITIUS, JSON.stringify(dispositius))
    } catch (e) {
      console.error("Error en desar dispositius a localStorage:", e)
    }
  }, [dispositius])

  // Desa el número de seqüència actual a localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SEQ_ID, String(seguentIdNum))
    } catch (e) {
      console.error("Error en desar seqüència a localStorage:", e)
    }
  }, [seguentIdNum])

  // Càlcul del recompte de dispositius per cada estat
  const comptadors = useMemo(() => {
    return {
      total: dispositius.length,
      enProva: dispositius.filter((d) => d.estat === 'En prova').length,
      apte: dispositius.filter((d) => d.estat === 'Apte').length,
      diagnosi: dispositius.filter((d) => d.estat === 'Diagnosi').length,
    }
  }, [dispositius])

  // Proves del dispositiu seleccionat per a la Fitxa de vida (ordenades de més recent a més antiga)
  const provesDelDispositiuActiu = useMemo(() => {
    if (!dispositiuActiu || !Array.isArray(provesData)) return []
    return provesData
      .filter((prova) => String(prova.deviceId) === String(dispositiuActiu.id))
      .sort((a, b) => (Number(b.test) || 0) - (Number(a.test) || 0))
  }, [dispositiuActiu])

  // Darrera prova realitzada (la que té el número de test més alt)
  const darreraProva = provesDelDispositiuActiu.length > 0 ? provesDelDispositiuActiu[0] : null

  // Comprovar si l'estat del dispositiu a l'inventari ja coincideix amb el resultat de la darrera prova
  const mateixEstat = Boolean(
    darreraProva && dispositiuActiu && dispositiuActiu.estat === darreraProva.result
  )

  // Aplicar el resultat de la darrera prova a l'estat del dispositiu en prémer el botó
  const handleAplicarResultat = () => {
    if (!darreraProva || !dispositiuActiu) return
    handleCanviEstat(dispositiuActiu.id, darreraProva.result)
  }

  // Llista filtrada segons cerca i selector d'estat
  const dispositiusFiltrats = useMemo(() => {
    return dispositius.filter((disp) => {
      const coincideixEstat =
        filtreEstat === 'tots' || disp.estat.toLowerCase() === filtreEstat.toLowerCase()
      const query = cerca.trim().toLowerCase()
      const coincideixCerca =
        query === '' ||
        disp.id.toLowerCase().includes(query) ||
        disp.tipus.toLowerCase().includes(query) ||
        disp.estat.toLowerCase().includes(query)

      return coincideixEstat && coincideixCerca
    })
  }, [dispositius, filtreEstat, cerca])

  // Canviar l'estat d'un dispositiu concret des del desplegable
  const handleCanviEstat = (id, nouEstat) => {
    setDispositius((prev) =>
      prev.map((disp) => (disp.id === id ? { ...disp, estat: nouEstat } : disp))
    )
    if (dispositiuActiu && dispositiuActiu.id === id) {
      setDispositiuActiu((prev) => (prev ? { ...prev, estat: nouEstat } : null))
    }
  }

  // Gestionar el registre d'un nou dispositiu
  const handleRegistrarDispositiu = (e) => {
    e.preventDefault()

    if (!tipusSeleccionat.trim()) {
      setErrorTipus('Cal seleccionar un tipus de dispositiu.')
      return
    }

    const nouDispositiu = {
      id: idGenerat,
      tipus: tipusSeleccionat,
      estat: 'En prova',
    }

    setDispositius((prev) => [...prev, nouDispositiu])
    setSeguentIdNum((prev) => prev + 1)
    setTipusSeleccionat('')
    setErrorTipus('')
  }

  // Classe CSS específica segons l'estat del dispositiu o resultat de prova
  const obtenirClasseEstat = (estat) => {
    switch (estat) {
      case 'En prova':
        return 'badge-en-prova'
      case 'Apte':
        return 'badge-apte'
      case 'Diagnosi':
        return 'badge-diagnosi'
      default:
        return 'badge-neutral'
    }
  }

  return (
    <div className="inventory-app">
      {/* Capçalera principal */}
      <header className="app-header">
        <div className="header-container">
          <div className="brand">
            <span className="brand-badge">REBOOT</span>
            <span className="brand-client">[client]</span>
          </div>
          <div className="header-meta">
            <span className="status-indicator"></span>
            <span>Dades sincronitzades en local</span>
          </div>
        </div>
      </header>

      {/* Contingut principal */}
      <main className="inventory-container">
        {/* Títol de la pantalla */}
        <div className="screen-header">
          <div>
            <h1>Inventari de dispositius</h1>
            <p className="subtitle">
              Gestió i seguiment dels equips assignats a REBOOT [client]
            </p>
          </div>
          <div className="total-badge">
            {comptadors.total} {comptadors.total === 1 ? 'dispositiu' : 'dispositius'} en total
          </div>
        </div>

        {/* Recompte superior de dispositius segons cada estat */}
        <section className="stats-section" aria-label="Recompte de dispositius per estat">
          <h2 className="stats-heading">Recompte per estat</h2>
          <div className="stats-grid">
            <div
              className={`stat-card stat-total ${filtreEstat === 'tots' ? 'stat-active' : ''}`}
              onClick={() => setFiltreEstat('tots')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setFiltreEstat('tots')}
              title="Prem per mostrar tots els dispositius"
            >
              <span className="stat-label">Total dispositius</span>
              <span className="stat-value">{comptadors.total}</span>
              <span className="stat-subtext">Tots els equips registrats</span>
            </div>

            <div
              className={`stat-card stat-en-prova ${filtreEstat === 'en prova' ? 'stat-active' : ''}`}
              onClick={() => setFiltreEstat('en prova')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setFiltreEstat('en prova')}
              title="Prem per filtrar els dispositius En prova"
            >
              <div className="stat-card-title-row">
                <span className="status-dot"></span>
                <span className="stat-label">En prova</span>
              </div>
              <span className="stat-value">{comptadors.enProva}</span>
              <span className="stat-subtext">Equips en fase de verificació</span>
            </div>

            <div
              className={`stat-card stat-apte ${filtreEstat === 'apte' ? 'stat-active' : ''}`}
              onClick={() => setFiltreEstat('apte')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setFiltreEstat('apte')}
              title="Prem per filtrar els dispositius Aptes"
            >
              <div className="stat-card-title-row">
                <span className="status-dot"></span>
                <span className="stat-label">Apte</span>
              </div>
              <span className="stat-value">{comptadors.apte}</span>
              <span className="stat-subtext">Equips validats i operatius</span>
            </div>

            <div
              className={`stat-card stat-diagnosi ${filtreEstat === 'diagnosi' ? 'stat-active' : ''}`}
              onClick={() => setFiltreEstat('diagnosi')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && setFiltreEstat('diagnosi')}
              title="Prem per filtrar els dispositius en Diagnosi"
            >
              <div className="stat-card-title-row">
                <span className="status-dot"></span>
                <span className="stat-label">Diagnosi</span>
              </div>
              <span className="stat-value">{comptadors.diagnosi}</span>
              <span className="stat-subtext">Equips pendents de revisió tècnica</span>
            </div>
          </div>
        </section>

        {/* Formulari per registrar un nou dispositiu */}
        <section className="form-card" aria-label="Formulari de registre de nou dispositiu">
          <div className="form-card-header">
            <div className="form-title-group">
              <svg
                className="form-icon"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="16"></line>
                <line x1="8" y1="12" x2="16" y2="12"></line>
              </svg>
              <h2>Registrar nou dispositiu</h2>
            </div>
            <p className="form-description">
              Introdueix les dades per incorporar un nou equip a l&apos;inventari
            </p>
          </div>

          <form onSubmit={handleRegistrarDispositiu} className="device-form" noValidate>
            <div className="form-fields-grid">
              {/* Identificador generat automàticament */}
              <div className="form-field">
                <label htmlFor="device-id">
                  Identificador (ID)
                  <span className="field-hint">Automàtic</span>
                </label>
                <div className="readonly-input-container">
                  <input
                    id="device-id"
                    type="text"
                    value={idGenerat}
                    readOnly
                    disabled
                    className="input-readonly"
                    aria-describedby="id-hint"
                  />
                </div>
                <small id="id-hint" className="field-help-text">
                  Generat seqüencialment pel sistema
                </small>
              </div>

              {/* Selector de tipus de dispositiu */}
              <div className={`form-field ${errorTipus ? 'has-error' : ''}`}>
                <label htmlFor="device-type">
                  Tipus de dispositiu <span className="required-mark">*</span>
                </label>
                <select
                  id="device-type"
                  value={tipusSeleccionat}
                  onChange={(e) => {
                    setTipusSeleccionat(e.target.value)
                    if (errorTipus) setErrorTipus('')
                  }}
                  className={`form-select ${errorTipus ? 'input-error' : ''}`}
                  aria-invalid={errorTipus ? 'true' : 'false'}
                  aria-describedby={errorTipus ? 'type-error-msg' : undefined}
                >
                  <option value="">-- Selecciona un tipus --</option>
                  {TIPUS_DISPOSITIU_CLIENT.map((tipus) => (
                    <option key={tipus} value={tipus}>
                      {tipus}
                    </option>
                  ))}
                </select>
                {errorTipus && (
                  <p id="type-error-msg" className="form-error-msg" role="alert">
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" y1="8" x2="12" y2="12"></line>
                      <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    {errorTipus}
                  </p>
                )}
              </div>

              {/* Estat inicial predeterminat: "En prova" */}
              <div className="form-field">
                <label htmlFor="device-status">
                  Estat inicial
                  <span className="field-hint">Fix</span>
                </label>
                <div className="status-preset-box">
                  <span className="status-badge badge-en-prova">
                    <span className="status-dot"></span>
                    En prova
                  </span>
                  <input
                    id="device-status"
                    type="hidden"
                    value="En prova"
                    readOnly
                  />
                </div>
                <small className="field-help-text">
                  Tots els equips nous comencen en prova
                </small>
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="submit-btn">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                  <polyline points="17 21 17 13 7 13 7 21"></polyline>
                  <polyline points="7 3 7 8 15 8"></polyline>
                </svg>
                Registrar dispositiu
              </button>
            </div>
          </form>
        </section>

        {/* Zona de controls i filtres */}
        <section className="controls-bar" aria-label="Filtres i cerca">
          <div className="search-box">
            <svg
              className="search-icon"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <input
              type="text"
              placeholder="Cerca per identificador, tipus o estat..."
              value={cerca}
              onChange={(e) => setCerca(e.target.value)}
              aria-label="Cerca de dispositius"
            />
            {cerca && (
              <button
                type="button"
                className="clear-search-btn"
                onClick={() => setCerca('')}
                aria-label="Neteja la cerca"
              >
                ✕
              </button>
            )}
          </div>

          <div className="filter-buttons" role="group" aria-label="Filtrar per estat">
            <button
              type="button"
              className={`filter-btn ${filtreEstat === 'tots' ? 'active' : ''}`}
              onClick={() => setFiltreEstat('tots')}
            >
              Tots ({comptadors.total})
            </button>
            <button
              type="button"
              className={`filter-btn ${filtreEstat === 'en prova' ? 'active' : ''}`}
              onClick={() => setFiltreEstat('en prova')}
            >
              En prova ({comptadors.enProva})
            </button>
            <button
              type="button"
              className={`filter-btn ${filtreEstat === 'apte' ? 'active' : ''}`}
              onClick={() => setFiltreEstat('apte')}
            >
              Apte ({comptadors.apte})
            </button>
            <button
              type="button"
              className={`filter-btn ${filtreEstat === 'diagnosi' ? 'active' : ''}`}
              onClick={() => setFiltreEstat('diagnosi')}
            >
              Diagnosi ({comptadors.diagnosi})
            </button>
          </div>
        </section>

        {/* Taula de l'inventari */}
        <section className="table-card" aria-label="Llista de dispositius">
          <div className="table-responsive">
            <table className="inventory-table">
              <thead>
                <tr>
                  <th scope="col">Identificador (ID)</th>
                  <th scope="col">Tipus de dispositiu</th>
                  <th scope="col">Canviar estat</th>
                  <th scope="col" className="th-actions">Accions</th>
                </tr>
              </thead>
              <tbody>
                {dispositiusFiltrats.length > 0 ? (
                  dispositiusFiltrats.map((dispositiu) => (
                    <tr key={dispositiu.id}>
                      <td className="cell-id">
                        <span className="id-chip">{dispositiu.id}</span>
                      </td>
                      <td className="cell-type">
                        <div className="type-badge">
                          <svg
                            className="laptop-icon"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            aria-hidden="true"
                          >
                            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                            <line x1="2" y1="20" x2="22" y2="20"></line>
                          </svg>
                          <span>{dispositiu.tipus}</span>
                        </div>
                      </td>
                      <td className="cell-status">
                        <div className="status-select-container">
                          <span
                            className={`status-dot ${obtenirClasseEstat(dispositiu.estat)}-dot`}
                            aria-hidden="true"
                          ></span>
                          <select
                            value={dispositiu.estat}
                            onChange={(e) => handleCanviEstat(dispositiu.id, e.target.value)}
                            className={`status-select ${obtenirClasseEstat(dispositiu.estat)}`}
                            aria-label={`Modificar estat del dispositiu ${dispositiu.id}`}
                          >
                            {ESTATS_DISPOSITIU.map((estat) => (
                              <option key={estat} value={estat}>
                                {estat}
                              </option>
                            ))}
                          </select>
                        </div>
                      </td>
                      <td className="cell-actions">
                        <button
                          type="button"
                          className="btn-fitxa-vida"
                          onClick={() => setDispositiuActiu(dispositiu)}
                          aria-label={`Veure la fitxa de vida del dispositiu ${dispositiu.id}`}
                        >
                          <svg
                            width="15"
                            height="15"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            aria-hidden="true"
                          >
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                          </svg>
                          Fitxa de vida
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="empty-state">
                      <div className="empty-message">
                        <p>No s&apos;ha trobat cap dispositiu que coincideixi amb els criteris.</p>
                        <button
                          type="button"
                          className="reset-filters-btn"
                          onClick={() => {
                            setFiltreEstat('tots')
                            setCerca('')
                          }}
                        >
                          Restablir filtres
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="table-footer">
            <span>
              Mostrant {dispositiusFiltrats.length} de {comptadors.total} dispositius
            </span>
            <span className="table-footer-note">Desat automàticament a localStorage</span>
          </div>
        </section>
      </main>

      {/* Modal / Vista de Fitxa de vida */}
      {dispositiuActiu && (
        <div
          className="fitxa-modal-overlay"
          onClick={() => setDispositiuActiu(null)}
          role="dialog"
          aria-modal="true"
          aria-labelledby="fitxa-vida-titol"
        >
          <div
            className="fitxa-modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Capçalera del modal */}
            <div className="fitxa-modal-header">
              <div className="fitxa-title-area">
                <span className="fitxa-tag">REBOOT [client]</span>
                <h2 id="fitxa-vida-titol">Fitxa de vida: {dispositiuActiu.id}</h2>
              </div>
              <button
                type="button"
                className="fitxa-close-btn"
                onClick={() => setDispositiuActiu(null)}
                aria-label="Tancar la fitxa de vida"
              >
                ✕
              </button>
            </div>

            {/* Dades del dispositiu */}
            <section className="fitxa-device-summary" aria-label="Dades del dispositiu">
              <div className="fitxa-device-item">
                <span className="fitxa-device-label">Identificador (ID):</span>
                <span className="id-chip">{dispositiuActiu.id}</span>
              </div>
              <div className="fitxa-device-item">
                <span className="fitxa-device-label">Tipus de dispositiu:</span>
                <span className="fitxa-device-val">{dispositiuActiu.tipus}</span>
              </div>
              <div className="fitxa-device-item">
                <span className="fitxa-device-label">Estat actual:</span>
                <span className={`status-badge ${obtenirClasseEstat(dispositiuActiu.estat)}`}>
                  <span className="status-dot"></span>
                  {dispositiuActiu.estat}
                </span>
              </div>
            </section>

            {/* Resultat de la darrera prova i botó per aplicar */}
            {darreraProva && (
              <section className="fitxa-latest-result-card" aria-label="Resultat de la darrera prova">
                <div className="latest-result-info">
                  <div className="latest-result-header-text">
                    <span className="latest-result-label">Resultat de la darrera prova</span>
                    <span className="latest-result-sub">Test #{darreraProva.test} (el més recent)</span>
                  </div>
                  <span className={`status-badge ${obtenirClasseEstat(darreraProva.result)}`}>
                    <span className="status-dot"></span>
                    {darreraProva.result}
                  </span>
                </div>
                <div className="latest-result-action">
                  <button
                    type="button"
                    className="btn-aplicar-resultat"
                    onClick={handleAplicarResultat}
                    disabled={mateixEstat}
                    title={
                      mateixEstat
                        ? "L'estat del dispositiu a l'inventari ja coincideix amb el resultat"
                        : `Establir l'estat del dispositiu com a «${darreraProva.result}»`
                    }
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    Aplica el resultat
                  </button>
                  {mateixEstat && (
                    <span className="applied-hint">L&apos;estat ja coincideix</span>
                  )}
                </div>
              </section>
            )}

            {/* Llista de proves del banc REBOOT */}
            <section className="fitxa-tests-section" aria-label="Proves del banc REBOOT">
              <div className="fitxa-tests-header">
                <h3>Historial de proves del banc</h3>
                <span className="tests-count-pill">
                  {provesDelDispositiuActiu.length}{' '}
                  {provesDelDispositiuActiu.length === 1 ? 'prova registrada' : 'proves registrades'}
                </span>
              </div>

              {provesDelDispositiuActiu.length > 0 ? (
                <div className="tests-list">
                  {provesDelDispositiuActiu.map((prova, index) => (
                    <article key={prova.test || index} className="test-card">
                      <div className="test-card-top">
                        <div className="test-number-badge">
                          <span className="test-num">Test #{prova.test}</span>
                          {prova.bench && (
                            <span className="test-bench-label">Banc: {prova.bench}</span>
                          )}
                        </div>
                        <span className={`status-badge ${obtenirClasseEstat(prova.result)}`}>
                          <span className="status-dot"></span>
                          {prova.result}
                        </span>
                      </div>

                      <div className="test-metrics-grid">
                        <div className="test-metric">
                          <span className="metric-label">Temperatura màxima:</span>
                          <span className="metric-val">
                            {prova.maxTempC != null ? `${prova.maxTempC} °C` : '-'}
                          </span>
                        </div>
                        {prova.tempC != null && (
                          <div className="test-metric">
                            <span className="metric-label">Temperatura:</span>
                            <span className="metric-val">{prova.tempC} °C</span>
                          </div>
                        )}
                        <div className="test-metric">
                          <span className="metric-label">Bateria:</span>
                          <span className="metric-val">
                            {prova.batteryPct != null ? `${prova.batteryPct}%` : '-'}
                          </span>
                        </div>
                      </div>

                      <div className="test-reasons-box">
                        <span className="reasons-label">Motius:</span>
                        <div className="reasons-content">
                          {Array.isArray(prova.reasons) ? (
                            <ul className="reasons-list">
                              {prova.reasons.map((motiu, idx) => (
                                <li key={idx}>{motiu}</li>
                              ))}
                            </ul>
                          ) : (
                            <p className="reasons-text">{prova.reasons || '-'}</p>
                          )}
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="fitxa-sense-proves">
                  <svg
                    width="36"
                    height="36"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                    className="no-tests-icon"
                  >
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                  </svg>
                  <p className="no-proves-msg">Encara no té proves</p>
                  <span className="no-proves-subtext">
                    Aquest dispositiu no disposa de registres en el banc de proves.
                  </span>
                </div>
              )}
            </section>

            {/* Peu del modal */}
            <div className="fitxa-modal-footer">
              <button
                type="button"
                className="btn-tancar-fitxa"
                onClick={() => setDispositiuActiu(null)}
              >
                Tancar
              </button>
            </div>
          </div>
        </div>
      )}

      <footer className="app-footer">
        <p>REBOOT [client] &bull; Sistema de gestió d&apos;inventari</p>
      </footer>
    </div>
  )
}

export default App
